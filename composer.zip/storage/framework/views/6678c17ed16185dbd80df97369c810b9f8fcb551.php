
<?php $__env->startSection('title'); ?> Список новостей - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Новости </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group me-2">
        <a href="<?php echo e(route('admin.slide.create')); ?>" class="btn btn-sm btn-outline-secondary">Добавить новую</a>
      </div>
    </div>
  </div>

      <h2>Section title</h2>
      <div class="table-responsive">
        <?php echo $__env->make('inc.message'/*, [
          'name' => 'Work'
        ]*/, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Заголовок</th>
              <th scope="col">Автор</th>
              <th scope="col">Дота добавления</th>
              <th scope="col">Действие</th>
            </tr>
          </thead>
          <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $newsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <?php if($loop->last): ?>
                  Это последняя итерация 
              <?php endif; ?>
                <tr>
                    <td><?php echo e($news->id); ?></td>
                    <td><?php echo e($news->title); ?></td>
                    <td><?php echo e($news->author); ?></td>
                    <td><?php echo e(now()->format('d-m-Y H-i')); ?></td>
                    <td>
                      <?php if($news->updated_at): ?>
                       <?php echo e($news->updated_at->format('d-m-Y H:i')); ?>

                      <?php else: ?> - <?php endif; ?>
                     </td>
                    <td>
                        <a href="<?php echo e(route( 'admin.slaide.edit', [ 'news' => $news] )); ?>">Ред.</a>&nbsp;|&nbsp;<a href="javascript:;" style="color: red">Уд.</a>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                      <td colspan="5">Записей нет</td>
                  </tr>
              <?php endif; ?>
              <div>
                
              </div>
            
          </tbody>
        </table>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layosts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\projectShop\projectShop\resources\views/admin/slaide/index.blade.php ENDPATH**/ ?>
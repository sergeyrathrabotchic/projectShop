
<?php $__env->startSection('title'); ?> Админка - <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Админка </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
    </div>
  </div>


      <div class="table-responsive">
      
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layosts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\projectShop\projectShop\resources\views/admin/index.blade.php ENDPATH**/ ?>
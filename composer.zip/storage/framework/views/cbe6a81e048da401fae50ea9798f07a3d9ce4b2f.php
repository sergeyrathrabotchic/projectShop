
<?php $__env->startSection('title'); ?> Список категорий - <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Категории </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group me-2">
        <a href="<?php echo e(route('admin.slides.create')); ?>" class="btn btn-sm btn-outline-secondary">Добавить новую</a>
      </div>
      
    </div>
  </div>

      <h2>Список картинок</h2>
      <div class="table-responsive">
        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Картинка</th>
              <!--<th scope="col">Автор</th>-->
              <th scope="col">Дота последнего обновления</th>
              <th scope="col">Действие</th>
            </tr>
          </thead>
          <tbody>
             
             
             <?php
                 $i = $page;
             ?>
            <?php $__empty_1 = true; $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php
                      $i = $i +1;
                  ?>
                 <tr>
                  <td><?php echo e($i); ?></td>
                  <td><img src="<?php echo e(Storage::disk('image')->url($slide->image)); ?>" alt="" style="width: 80%;padding: 10px;"></td>
                  <td>
                    <?php if($slide->updated_at): ?>
                     <?php echo e($slide->updated_at->format('d-m-Y H:i')); ?>

                    <?php else: ?> - <?php endif; ?>
                   </td> 
                   
                    <td>
                      <a href="<?php echo e(route('admin.slides.edit', ['slide' => $slide->id ])); ?>" class="btn btn-primary">Ред.</a>
                      
                      
          
                      
                      <form  action="<?php echo e(route('admin.slides.destroy' , ['slide' => $slide->id ])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>           
                        <button name="_method" type="hidden" value="DELETE" class="btn btn-danger" style="margin-top: 5px;">Удалить</button>
                    </form>
                    </td>
                 </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <tr>
                    <td colspan="4">Таких записей нет</td>
                 </tr>
             <?php endif; ?>
            
          </tbody>
        </table>
      </div>
      <div>
        <?php echo e($slides->links()); ?>

      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layosts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\projectShop\projectShop\resources\views/admin/slide/index.blade.php ENDPATH**/ ?>
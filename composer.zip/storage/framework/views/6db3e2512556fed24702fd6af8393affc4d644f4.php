
<?php $__env->startSection('title'); ?> Список новостей - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <!--<div class="col">
        <div class="card shadow-sm">
          <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>

          <div class="card-body">
            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
                <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
              </div>
              <small class="text-muted">9 mins</small>
            </div>
          </div>
        </div>
      </div>-->
<?php if(!empty($newsList)): ?>
<?php
//$a = [1,2,3];
    //dd($a);
    //dd($newsList);
    //print_r($newsList[0])
?>
<?php $__currentLoopData = $newsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($_GET['categoryId'] == $news->category_id): ?>

        <div class="col">
            <div class="card shadow-sm">
            <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text></svg>

            <div class="card-body">
                <p class="card-text"><strong><?php echo e($news->title); ?></strong> <br> <?php echo $news->description; ?>.</p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
                2
                <a href="<?php echo e(route('news.show',['id' => $news->id,'categoryId' => $news->category_id])); ?>" class="btn btn-sm btn-outline-secondary">Смотреть подробние</a>
              </div>
                <small class="text-muted">Автор: <?php echo e($news->author); ?> <br>
                <?php echo e(now()->format('d-m-Y H:i')); ?></small>
            </div>
            </div>
            </div>
        </div>


    <?php endif?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
    <p>Новостей нет</p>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layosts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\hj\projectShop\resources\views/news/index.blade.php ENDPATH**/ ?>
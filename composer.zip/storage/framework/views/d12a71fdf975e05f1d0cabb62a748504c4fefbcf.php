
<?php $__env->startSection('title'); ?> Добавить новую новость - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Добавить новость </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
    </div>
  </div>

      <div class="table-responsive">
        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form  method="post" action="<?php echo e(route('admin.news.store'/*,['status' => 'new']*/)); ?>">
          <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="category_id">Категория</label>
              <select name="category_id" for="form-control" id="category_id">
                <option value="0">Нет категории</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(old('category_id') === $category->id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>  
            <div class="form-group">
                <label for="title">Наименование</label>
                <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>">
            </div>
            <div class="form-group">
              <label for="autor">Автор</label>
              <input type="text" class="form-control" name="autor" id="autor" value="<?php echo e(old('autor')); ?>">
            </div>
            <div class="form-group">
              <label for="status">Статус</label>
              <select name="status" for="form-control" id="status">
                <option <?php if(old('status') === 'DRAFT'): ?> selected <?php endif; ?>>DRAFT</option>
                <option <?php if(old('status') === 'BLOCKED'): ?> selected <?php endif; ?>>BLOCKED</option>
                <option <?php if(old('status') === 'PUBLISHED'): ?> selected <?php endif; ?>>PUBLISHED</option>
              </select>
            </div>
            <div class="form-group">
              <label for="description">Описание</label>
              <textarea type="text" class="form-control" name="description" id="description" ><?php echo e(old('description')); ?></textarea>
            </div>
            <br>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layosts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\projectShop\projectShop\resources\views/admin/news/create.blade.php ENDPATH**/ ?>
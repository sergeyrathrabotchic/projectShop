sergeyrathrabotchic    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    1997SergeySemkin




E325: ATTENTION
Found a swap file by the name ".git/.MERGE_MSG.swp"
          owned by: u1685020   dated: Thu Sep 15 11:40:14 2022
         file name: ~u1685020/www/angelisolo.ru/projectShop/.git/MERGE_MSG
          modified: YES
         user name: u1685020   host name: server75.hosting.reg.ru
        process ID: 142082
While opening file ".git/MERGE_MSG"
             dated: Thu Sep 15 11:52:55 2022
      NEWER than swap file!

(1) Another program may be editing the same file.  If this is the case,
    be careful not to end up with two different instances of the same
    file when making changes.  Quit, or continue with caution.
(2) An edit session for this file crashed.
    If this is the case, use ":recover" or "vim -r .git/MERGE_MSG"
    to recover the changes (see ":help recovery").
    If you did this already, delete the swap file ".git/.MERGE_MSG.swp"
    to avoid this message.
".git/MERGE_MSG" 7L, 311C
Press ENTER or type command to continue

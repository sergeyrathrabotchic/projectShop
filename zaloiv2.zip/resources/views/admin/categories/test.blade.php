<?php 

echo '<pre>'; 
print_r($categories); 
echo '</pre>';

?>
